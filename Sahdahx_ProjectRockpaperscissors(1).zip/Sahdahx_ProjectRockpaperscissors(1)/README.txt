# Rock Paper Scissors Image Classification

## Deskripsi

Proyek ini adalah implementasi klasifikasi gambar menggunakan deep learning untuk mengenali tangan yang membentuk gunting, batu, atau kertas (Rock, Paper, Scissors). Proyek ini dilatih menggunakan dataset rockpaperscissors dan memanfaatkan TensorFlow dan Keras.

## Instalasi

1. Unduh dataset: [rockpaperscissors.zip](https://github.com/dicodingacademy/assets/releases/download/release/rockpaperscissors.zip).
2. Ekstrak file zip ke direktori proyek.
3. Buka notebook atau script Python di lingkungan pengembangan favorit Anda.

## Persyaratan Sistem

- Python 3.6 atau versi lebih tinggi.
- TensorFlow dan Keras.

## Cara Penggunaan

1. Jalankan notebook atau script Python untuk melatih model di google colab.
2. Ikuti langkah-langkah di dalamnya untuk melihat pelatihan dan hasil validasi.

## Referensi

- dicoding

## Kontak

**Nama:** Sahda Huwaidah Estiningtyas
**Email:** estiningtyas.leaf@gmail.com
**Profil Dicoding:** https://www.dicoding.com/users/sahdahx

